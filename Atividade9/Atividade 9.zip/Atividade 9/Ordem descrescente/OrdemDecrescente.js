
function Decrescente() {
	var numero1 = document.getElementById("numero1");
	var numero2 = document.getElementById("numero2");
	var numero3 = document.getElementById("numero3");

	OrdemDecrescente(numero1.value, numero2.value, numero3.value);

	function OrdemDecrescente(num1, num2, num3) {
	var arrayDecrescente = [num1, num2, num3];
	arrayDecrescente.sort((a, b) => b - a);
	alert(arrayDecrescente);
	}

}