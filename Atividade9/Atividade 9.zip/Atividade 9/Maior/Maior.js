
function Maior() {
	var numero1 = document.getElementById("numero1");
	var numero2 = document.getElementById("numero2");
	var numero3 = document.getElementById("numero3");

	maiorNumero(numero1.value, numero2.value, numero3.value);

	function maiorNumero(numero1, numero2, numero3) {
		var arrayNumero = [numero1, numero2, numero3];

		arrayNumero.sort((a, b) => a - b);

		alert("Maior número: "+ arrayNumero[arrayNumero.length - 1]);
	}

}